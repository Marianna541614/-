﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace калькулятор_ВУЗ
{
    public partial class Form1 : Form
    {
           

        String operationSign = "0", firstNumber = "0";
       



        public Form1()
        {
            InitializeComponent();
           
        }



        private void button1_Click(object sender, EventArgs e)
        {

            Button B = (Button)sender;

            if (textBox1.Text == "0")
            {
                textBox1.Text = B.Text;
            }
            else
            {

                textBox1.Text = textBox1.Text + B.Text;

            }


            buttonEqually.Focus();

        }

        private void cleanAll(object sender, EventArgs e)
        {

            textBox1.Text = "0";
            textBox2.Text = "0";
            firstNumber = "0";
            operationSign = "0";

            buttonEqually.Focus();

        }

        private void operation(object sender, EventArgs e)
        {
            Button B = (Button)sender;
            operationSign = B.Text;

            if (firstNumber == "0")
            {
                
                firstNumber = textBox1.Text;

                textBox1.Text = "0";

                if (firstNumber == "0" & textBox1.Text == "0" & operationSign == "-")
                {
                    textBox1.Text = "-";
                    operationSign = "0";
                    
                }
                //textBox2.Text = firstNumber;
                

            }
           

            buttonEqually.Focus();

           

        }

        private void delete_one_simbol(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text.Remove(textBox1.Text.Length - 1);

            buttonEqually.Focus();
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            //MessageBox.Show(Convert.ToString(e.KeyValue));
            if (!e.Shift)
            {

                switch (e.KeyValue)
                {
                    case 48:
                    case 96:
                        {
                            button0.PerformClick();
                            break;
                        }
                    case 49:
                    case 97:
                        {
                            button1.PerformClick();
                            break;
                        }
                    case 50:
                    case 98:
                        {
                            button2.PerformClick();
                            break;
                        }
                    case 51:
                    case 99:
                        {
                            button3.PerformClick();
                            break;
                        }
                    case 52:
                    case 100:
                        {
                            button4.PerformClick();
                            break;
                        }
                    case 53:
                    case 101:
                        {
                            button5.PerformClick();
                            break;
                        }
                    case 54:
                    case 102:
                        {
                            button6.PerformClick();
                            break;
                        }
                    case 55:
                    case 103:
                        {
                            //MessageBox.Show(Convert.ToString(e.KeyValue));
                            button7.PerformClick();
                            break;
                        }
                    case 56:
                    case 104:
                        {
                            button8.PerformClick();
                            break;
                        }
                    case 57:
                    case 105:
                        {
                            button9.PerformClick();
                            break;
                        }
                    case 106:
                        {
                            buttonM.PerformClick();
                            break;
                        }
                    case 187:
                    case 107:
                        {
                            buttonPlas.PerformClick();
                            break;
                        }
                    case 109:
                    case 189:
                        {
                            buttonMinus.PerformClick();
                            break;
                        }
                    case 111:
                        {
                            buttonDiv.PerformClick();
                            break;
                        }
                    case (char)Keys.Enter: // keys - номер клавиши.
                        {
                            //MessageBox.Show(Convert.ToString(e.KeyValue));
                            buttonEqually.PerformClick();
                            break;
                        }
                    case 46:
                        {
                            buttonD.PerformClick();
                            break;
                        }
                    case 8:
                        {
                            buttonBack.PerformClick();
                            break;
                        }
                    case 110:
                        {
                            buttonCommo.PerformClick();
                            break;
                        }

                }
            }
            else
            {

                switch (e.KeyValue)
                {
                    case 191:
                        {
                            buttonDiv.PerformClick();
                            break;
                        }
                    case 190:
                        {
                            buttonCommo.PerformClick();
                            break;
                        }
                    case 187:
                        {
                            buttonPlas.PerformClick();
                            break;
                        }
                    case 56:
                        {
                            buttonM.PerformClick();
                            break;
                        }
                }

            }
             
            
            

            buttonEqually.Focus();
                
            
        }

        private void commo(object sender, EventArgs e)
        {
            
            int i = textBox1.Text.IndexOf(",", 0, textBox1.Text.Length);
            if (i == -1)
            {
                textBox1.Text += ",";
            }
            
        }
        //5+5=10+4
        private void equally(object sender, EventArgs e)
        {
            
            switch (operationSign)
            {
                case "+":
                    {
                        Double b = Convert.ToDouble(firstNumber) + Convert.ToDouble(textBox1.Text);
                        textBox2.Text = b.ToString();
                        textBox1.Text = "0";
                        firstNumber = "0";
                        operationSign = "0";
                        break;
                    }
                case "-":
                    {
                        Double b = Convert.ToDouble(firstNumber) - Convert.ToDouble(textBox1.Text);
                        textBox2.Text = b.ToString();
                        textBox1.Text = "0";
                        firstNumber = "0";
                        operationSign = "0";
                        break;
                    }
                case "/":
                    {
                        if (operationSign == "/" & textBox1.Text == "0")
                        {
                            MessageBox.Show("Ошибка");
                            break;
                        }
                       
                        Double b = Convert.ToDouble(firstNumber) / Convert.ToDouble(textBox1.Text);
                        textBox2.Text = b.ToString();
                        textBox1.Text = "0";
                        firstNumber = "0";
                        operationSign = "0";
                        break;
                        
                    }
                case "x":
                    {
                        Double b = Convert.ToDouble(firstNumber) * Convert.ToDouble(textBox1.Text);
                        textBox2.Text = b.ToString();
                        textBox1.Text = "0";
                        firstNumber = "0";
                        operationSign = "0";
                        break;
                    }
            }
        }
    }
}
